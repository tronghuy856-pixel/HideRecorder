plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.gamerecorder"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.gamerecorder"
        minSdk = 29
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
    }
}
